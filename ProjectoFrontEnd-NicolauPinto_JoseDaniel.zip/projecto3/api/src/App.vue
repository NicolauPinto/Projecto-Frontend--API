<template>
  <div>
    <v-app-bar color="deep-purple accent-4" dark dense>
      
      <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>

      <v-btn icon router-link to="/Produtos">
        <v-icon >mdi-pokemon-go</v-icon>
      </v-btn>
      <v-btn icon router-link to="/Produto">
        <v-icon >mdi-ab-testing</v-icon>
      </v-btn>
      <v-btn icon router-link to="/">
        <v-icon >mdi-home-variant-outline</v-icon>
      </v-btn>
    </v-app-bar>

    <v-navigation-drawer v-model="drawer" absolute bottom temporary>

      <v-list nav dense>
        <v-list-item-group
          v-model="group"
          active-class="deep-purple--text text--accent-4">

          <v-list-item>
            <v-list-item-title>
              <router-link to="/">
                  Home
                </router-link>
              </v-list-item-title>
          </v-list-item>

          <v-list-item>
            <v-list-item-title>
              <router-link to="/Produtos">
                  Produtos
                </router-link>
              </v-list-item-title>
          </v-list-item>

          <v-list-item>
            <v-list-item-title>
              <router-link to="/Produto">
                  Produto
                </router-link>
              </v-list-item-title>
          </v-list-item>

          <v-list-item>
            <v-list-item-title>
              <router-link to="/Login">
                Login
              </router-link>
            </v-list-item-title>
          </v-list-item>

          <v-list-item>
            <v-list-item-title>
              <router-link to="/Registo">
                Registo
              </router-link>
            </v-list-item-title>
          </v-list-item>


          <v-list-item>
            <v-list-item-title>
              <router-link to="/AdicionarCarta">
                Adicionar nova carta
              </router-link>
            </v-list-item-title>
          </v-list-item>

          <v-list-item>
            <v-list-item-title>
              <router-link to="/NovasCartas">
                Novas Cartas
              </router-link>
            </v-list-item-title>
          </v-list-item>

        </v-list-item-group>
      </v-list>
    </v-navigation-drawer>
      <router-view></router-view>
      


<div id="mainContainer">
  <div class="catchme"><img src="https://fontmeme.com/permalink/200810/6b00c8ed9bd86f245b8761a62572cab6.png" alt="pokemon-font" border="0"></div>
  <div id="topContainer">
  </div>
  <div id="buttonContainer">
      <button class="roundbtn btn btn-light" type="button"><v-icon class="fab">mdi-facebook</v-icon></button>
      <button class="roundbtn btn btn-light" type="button"><v-icon class="linked">mdi-linkedin</v-icon></button>
      <button class="roundbtn btn btn-light" type="button"><v-icon class="twitter">mdi-twitter</v-icon></button>
      <button class="roundbtn btn btn-light" type="button"><v-icon class="youtube">mdi-youtube</v-icon></button>
  </div>
  <div id="bottomContainer">
  </div>
</div>
  </div>
  
  
</template>


<script>
export default {
  name: "App",
  data: () => ({
    drawer: false,
    group: null,
  }),

  watch: {
    group() {
      this.drawer = false;
    },
  },
};
</script>
<style>
.catchme {
  align-items: flex-end;
  display:flex;
  justify-content: center;
  width: 100%;
  padding: 20px;
  
  z-index: 2;
}

.roundbtn:hover {
  background-color: #DC3545;
}
#mainContainer {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

#buttonContainer {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-around;
  background-color: black;
  height: 0.5em;
  width: 28.5em;
  z-index: 3;
}

#topContainer {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: #DC3545;
  height: 3.5em;
  width: 40em;
  z-index: 2;
  border-top-left-radius: 3.5em;  
  border-top-right-radius: 3.5em;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.8);
}

#bottomContainer {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-around;
  z-index: 1;
  height: 3.5em;
  width: 40em;
  border-bottom-left-radius: 3.5em;  
  border-bottom-right-radius: 3.5em;
  background-color: white;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.8);
}

.roundbtn {
  height: 3em;
  width: 3em;
  border-radius: 50%;
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.8);
  position: relative;
}

.roundbtn:hover {
  color: #DC3545;
}

.roundbtn::before {
  content: " ";
  background-color: black;
  height: 5em;
  width: 5em;
  position: absolute;
  top: -1em;
  left: -1em;
  z-index: -1;
  border-radius: 50%;
}

.roundbtn::after {
  content: " ";
  background-color: white;
  height: 4em;
  width: 4em;
  position: absolute;
  top: -0.5em;
  left: -0.5em;
  z-index: -1;
  border-radius: 50%;
}




/* // pokeball loader // */



.asd{
    -webkit-box-sizing: border-box;
       -moz-box-sizing: border-box;
            box-sizing: border-box;
}

body{
  background-color: #192935;
  font-family: "pkmn", monospace;
}

.wrapper
{
    position: absolute;
    top: 50%;
    left: 50%;

   transform: translate(-50%, -50%);

}

.pokeball {
  width: 60px;
  height: 60px;
  background-color: #fff;
  border-radius: 50% ;
  position: relative;
  overflow: hidden;
  border: 3px solid;
  animation: frames .8s  linear 0s infinite;
}

.pokeball:after{
  content: '';
  position: absolute;
  width: 60px;
  height: 30px;
  background-color: red;
  border-bottom: 4px solid;
  top: -4px
}

.pokeball:before{
  content: '';
  position: absolute;
  background-color: #fff;
  width: 10px;
  height:10px;
  border: 4px solid;
  border-radius: 50%;
  bottom: 18px;
  right: 18px;
  z-index: 1;
}
@font-face {
  font-family: "pkmn";
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url("https://assets.codepen.io/13471/Pokemon-DPPt.woff2") format("woff2"), url("https://assets.codepen.io/13471/pokemon-DPPt.woff") format("woff");
}

/* AnimationFrames */
@keyframes frames{
  0% {
    transform: rotate(0deg);
  }
  100%{
    transform: rotate(360deg);
  }
}
</style> */