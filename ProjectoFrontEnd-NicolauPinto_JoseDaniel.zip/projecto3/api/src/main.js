import Vue from 'vue'
import App from './App.vue'
import router from './router'
import vuetify from './plugins/vuetify';
import firebase from 'firebase';



Vue.config.productionTip = false

new Vue({
  router,
  vuetify,
  render: h => h(App)
}).$mount('#app')

    
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDfgHutwm9ziQi7_9laG2QiDkz5XCKhQX8",
  authDomain: "pokemonapi-1d542.firebaseapp.com",
  projectId: "pokemonapi-1d542",
  storageBucket: "pokemonapi-1d542.appspot.com",
  messagingSenderId: "232653965153",
  appId: "1:232653965153:web:8855ca06d6710cfd7fa720",
  measurementId: "G-MESF5ZXM55"
};

firebase.initializeApp(firebaseConfig);


