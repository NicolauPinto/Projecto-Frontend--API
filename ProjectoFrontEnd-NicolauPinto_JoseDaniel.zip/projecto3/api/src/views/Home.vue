<template>
  <div class="home">
    <div class="caixadetexto">
    <h1 class="titulo">Pokemon Trading Game</h1>
    <p class="paragrafos">Pokémon Trading Card Game, ou Pokémon Estampas Ilustradas no Brasil (originalmente: ポケモンカードゲーム, Pokemon Card Game), é um jogo de cartas colecionáveis baseadas na franquia japonesa Pokémon.

Publicado, pela primeira vez em outubro de 1996 pela Media Factory no Japão. Nos Estados Unidos, foi inicialmente publicado pela Wizards of the Coast; sendo assumida pela Nintendo em junho de 2003.[1]

No Brasil, foi lançado em 2000 pela Devir Livraria,[2] sendo assumido pela Copag em 2011.[3]

O jogo foi vendido em 23.6 bilhões de cartas ao redor do mundo.[4] em 2014 O jogo teve uma adaptação para o online e liberado para download no site oficial do Pokémon e nas plataformas Apple Store e Google Play Store</p>
<img class="imagem" src="https://pngimg.com/uploads/pokeball/pokeball_PNG21.png" alt="">
    </div>
  </div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'Home',
  components: {

  }
}

</script>

<style scoped>
html {
  height: 100%;
  width: 100%;
}
.home {
  background-image: url("https://static1.gamerantimages.com/wordpress/wp-content/uploads/2021/04/pokemon-card-backs.jpg") ;
  background-size: cover;
  background-position: center;
  height: 950px;
  display:flex;
  justify-content: center;
  align-items: center;
  
  
}
.caixadetexto {
  background-color: black;
  width: 1200px;
  height: 700px;
  opacity: 0.8;
  padding-left:30px;
  padding-right: 30px;

}
.titulo {
  color: white;
  text-align: center;
  margin-top: 45px;
  font-size: 75px;
}
.paragrafos {
  color: white;
  text-align: center;
  margin-top: 45px;
  font-size:25px;
}
.imagem {
  width: 340px;
  opacity: 1;
  margin-top: 20px;
}

</style>

