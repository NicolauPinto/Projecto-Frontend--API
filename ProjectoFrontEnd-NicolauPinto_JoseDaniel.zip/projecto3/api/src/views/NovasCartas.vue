<template>
  <v-container>
    <div class="bg">   
     <div class="novasCartasPesquisa">
        <div v-for="(api, index) in pokeapi" :key="index">
              <img :src="api.Foto">
        </div>
      </div>
    </div>
  </v-container>
</template>

<script>
import axios from "axios";
export default {
    name: 'App',
    data() {
    return {
        pokeapi: null,
    };
  },
  mounted() {
    var that = this;
    axios
      .get("https://pokemon-tcg-api-online-default-rtdb.firebaseio.com/.json")
      .then(response => (this.pokeapi = response.data));
    console.log(that.info);
  },
}
</script>

<style scoped>

html, body {
    height: 100%;
    margin: 0;
    padding: 0;
}

#app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px;
}

.novasCartasPesquisa {
  display: grid;
  grid-template-columns: 250px 250px 250px 250px;
  padding-left: 0px;
  grid-gap: 30px;
  height: 361px;
  width: 255px;
}

.outer {
    display: flex;
    flex: 1;
    width: auto;
    height: 100%;
    padding: 0 20px;
    flex-flow: row nowrap;
    align-items: center;
}
.inner-content {
    flex-shrink: 0;
    align-items: center;
    justify-content: center;
    width: 100px;
    height: calc(100% - 40px);
    border: solid 1px #2c3e50;
    border-radius: 5px;
}
.inner-content:not(:first-of-type) {
    margin-left: 30px;
}
</style>