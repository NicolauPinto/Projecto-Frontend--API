<template>
    <v-container>
        <div  class="wrapper">
      </div>
        <div class="row">
        
        <v-snackbar
            v-model="snackbar"
            :multi-line="multiLine"
        >
            {{ text }}

            <template v-slot:action="{ attrs }">
                <v-btn
                color="red"
                text
                v-bind="attrs"
                @click="snackbar = false"
                >
                Close
                </v-btn>
            </template>
        </v-snackbar>
      <div class="colunas">
        <div class="colunaProduct">
          <v-card max-width="500"
              class="mx-auto my-12 lista" v-for="(item, index) in info" :key="index">
            
                  <div v-if="index <111"> 
                    <v-card-title class="v-cardtitle">{{item.name}}</v-card-title>
                  <hr>
                  <div class="detalhes">
                  <p> Tipo: {{item.types[0]}}</p>
                  <div v-if="item.evolvesFrom"> 
                    evoluiu de: {{item.evolvesFrom}}
                  </div>
                  <div v-if="!item.evolvesFrom"> 
                  Não tem evolucao na fase 1
                  </div>
                  Ataques:
                  <div v-for="(ataque, id) in item.attacks" :key="id">
                      Nome do ataque  {{ataque.name}}  <br>
                      Custo do ataque  {{ataque.cost}}
                  </div>
                  </div>
                  <img scr="https://www.pokemon.com/us/pokedex/bulbasaur"/> 
                  <v-card-text>
                  

                </v-card-text>
  

                <v-card-actions>
                  <v-btn
                    color="deep-purple "
                    text
                    @click="favorito(item)"
                  >
                    Guardar como Favorito
                  </v-btn>
                </v-card-actions>
                  </div>
            </v-card >
          </div>
<!-- isto -->
          <div class="colunaPesquisa">
        
            <div v-for="(api, index) in pokeapi" :key="index">
            
              <img :src="api.images.small" />
            </div>
          </div>
  <!-- ate aqui -->
        </div>

      
        <!-- Lista favoritos-->
        <div class="colunaFav">

            <div v-if="favoritos.length >0">
              <h3>Favoritos</h3>
              <div v-for="(fav, index) in favoritos" :key="index">
                  {{fav.name}} <v-icon class="butaofav" x-small @click="removeFav(index)">mdi-close-circle-outline</v-icon>
              </div>
            </div>

        </div> 
<!-- Lista Produtos -->
  </div>
   </v-container>
</template>

<style scoped>
.butaofav{
  color: white;
}
.detalhes {
  margin-top: 20px;
}
.v-cardtitle{
  display: flex;
  justify-content: center;
  margin: 0px;
  padding: 0px;
  
}
.lista {
  display: flex;
  flex-direction: column;
  text-align: center;
  margin-bottom: 20px;
}
.container {
  background-image: url("https://i.pinimg.com/originals/62/10/0c/62100ce9db7441c6918f1b01673118cd.png");
  background-repeat: repeat;
  
  
}
.row {
  display: flex;
}

.colunaProduct {
  flex: 30%;
  padding: 10px;
  
}


.colunaPesquisa {
  display: grid;
  grid-template-columns: 300px 300px 300px  ;
  padding-left: 70px;
  grid-gap: 30px;
  height: 350px;
  
}

.colunaFav {
  flex: 5%;
  padding: 10px;
  color: white;
}

.colunas {
  display: flex;
}
</style>



<script>
import axios from "axios";

export default {
  data() {
    return {
        info: null,
        pokeapi: null,
        favoritos: [],
        vertical: true,
        snackbar: false,
        text:'Esse item já foi adicionado aos favoritos',
    };
  },
  mounted() {
    var that = this;
    axios
      .get("https://api.pokemontcg.io/v2/cards")
      .then(response => (this.info = response.data.data));
    console.log(that.info);

    // cartas

    axios
          .get("https://api.pokemontcg.io/v2/cards")
          //  .get("https://api.pokemontcg.io/v1/cards?name=pikachu")
            .then(response => (this.pokeapi = response.data.data));



  },
  methods: {
    favorito(item) {
        if(this.favoritos.indexOf(item)===-1){
            this.favoritos.push(item);
            console.log(this.favoritos);
        }else{
            this.snackbar=true;
        }
    },
    removeFav(item){
        this.favoritos.splice(item,1)
    },
    procura(pesquisa){
      console.log("vai pesquisar pelo " + pesquisa);
        axios
            .get("https://api.pokemontcg.io/v2/cards?q=name:"+pesquisa)
            .then(response => (this.pokeapi = response.data.data));
    },
  },
};
</script>