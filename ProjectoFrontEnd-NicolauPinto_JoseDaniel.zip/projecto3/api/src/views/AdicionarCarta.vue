<template>
    <div class="form">
        <div class = "input-control">
            <label> Card </label>
            <input type = "text" v-model="novoPokemon.Card">
        </div>
 
        <div class = "input-control">
            <label> Preço </label>
            <input type = "text" v-model="novoPokemon.Preco">
        </div>
 
        <div class = "input-control">
            <label> Foto </label>
            <input type = "text" v-model="novoPokemon.Foto">
        </div>
 
        <input type = "submit" value="Enviar" @click="submeterFormulario()"/>
 
    </div>
</template>
<script>
import axios from 'axios'
 
export default  {
    data() {
        return {
            novoPokemon: {
                Card: '',
                Preco: '',
                Foto: ''
            }
        }
    },

    methods: {
        submeterFormulario() {
            alert("Inseriu a nova carta com sucesso");
            return axios.post('https://pokemon-tcg-api-online-default-rtdb.firebaseio.com/.json', this.novoPokemon);
        }
    }
}

</script>

<style scoped>

.form {
    max-width: 550px;
    box-sizing: border-box;
    margin: 30px;
    margin-top: 60px;
    padding: 30px;
    text-align: justify;
    box-shadow: 0 0 24px rgba(0, 0, 0, 0.3);
    width: 100%;
}

.button:hover {
    font: inherit;
    cursor: pointer;
    border-radius: 4px;
    border: 1px solid #06c4d1;
    background-color: white;
    color: #06c4d1;
    text-decoration: none;
    padding: 10px 30px;
}

.button:hover,
.button:active {
    color: #fff;
    background-color: #06c4d1;
}
 
.input-control {
    margin: 10px 0;
}
 
.input-control label {
    display: block;
    font-weight: bold;
    color: #06c4d1;
}
 
.input-control input {
    display: block;
    width: 100%;
    box-sizing: border-box;
    font: inherit;
    border: 1px solid #ccc;
    border-radius: 4px;
    padding: 5px;
}
 
.input-control input:focus {
    background-color: #eee;
    outline: none;
}
 
</style>

