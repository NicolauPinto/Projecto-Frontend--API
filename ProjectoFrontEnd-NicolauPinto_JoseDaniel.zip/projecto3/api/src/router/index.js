import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Produto from '../views/Produto.vue'
import Produtos from '../views/Produtos.vue'
import Login from '../views/Login.vue'
import Erro from '../views/Erro.vue'
import Registo from '../views/Registo.vue'
import NovasCartas from '../views/NovasCartas.vue'
import AdicionarCarta from '../views/AdicionarCarta.vue'


Vue.use(VueRouter)

const routes = [ 
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  
  {
    path: '/Produto/',
    name: 'Produto',
    component: Produto
  },
  {
    path: '*',
    name: 'Erro',
    component: Erro
  },
  {
    path: '/Produtos',
    name: 'Produtos',
    component: Produtos
  },
  {
    path: '/Login',
    name: 'Login',
    component: Login
  },
  {
    path: '/NovasCartas',
    name: 'NovasCartas',
    component: NovasCartas
  },
  {
    path: '/Registo',
    name: 'Registo',
    component: Registo
  },
  {
    path: '/AdicionarCarta',
    name: 'AdicionarCarta',
    component: AdicionarCarta
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
