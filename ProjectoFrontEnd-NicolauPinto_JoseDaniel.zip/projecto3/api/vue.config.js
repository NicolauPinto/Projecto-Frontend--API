module.exports = {
  transpileDependencies: [
    'vuetify'
  ]
}